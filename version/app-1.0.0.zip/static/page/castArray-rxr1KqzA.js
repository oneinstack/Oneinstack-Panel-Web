import{bn as r}from"./index-BpgbG9_h.js";function n(){if(!arguments.length)return[];var n=arguments[0];return r(n)?n:[n]}export{n as c};
