import{ah as a}from"./index-DP8kN_e6.js";const o=(...o)=>r=>{o.forEach((o=>{a(o)?o(r):o.value=r}))};export{o as c};
