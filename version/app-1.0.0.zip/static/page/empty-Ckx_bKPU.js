const e=""+new URL("../images/empty.webp",import.meta.url).href;export{e as _};
