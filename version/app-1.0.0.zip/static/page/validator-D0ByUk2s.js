import{bn as s}from"./index-DqDrVQpg.js";const i=i=>["",...s].includes(i);export{i};
