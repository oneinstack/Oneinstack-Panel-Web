import{bH as r}from"./index-CLbr8x7R.js";function n(){if(!arguments.length)return[];var n=arguments[0];return r(n)?n:[n]}export{n as c};
