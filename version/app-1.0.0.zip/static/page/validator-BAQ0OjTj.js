import{bQ as s}from"./index-C800588_.js";const i=i=>["",...s].includes(i);export{i};
