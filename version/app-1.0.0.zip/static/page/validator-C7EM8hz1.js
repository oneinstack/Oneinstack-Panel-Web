import{bq as s}from"./index-BS4biTff.js";const i=i=>["",...s].includes(i);export{i};
