import{bM as r}from"./index-RpX_sd6o.js";function n(){if(!arguments.length)return[];var n=arguments[0];return r(n)?n:[n]}export{n as c};
