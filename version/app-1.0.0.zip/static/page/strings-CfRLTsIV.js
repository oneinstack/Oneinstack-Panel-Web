import{cK as e}from"./index-CLbr8x7R.js";const a=(e="")=>e.replace(/[|\\{}()[\]^$+*?.]/g,"\\$&").replace(/-/g,"\\x2d"),c=a=>e(a);export{c,a as e};
