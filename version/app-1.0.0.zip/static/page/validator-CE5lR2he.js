import{bD as s}from"./index-B0-DY18Y.js";const i=i=>["",...s].includes(i);export{i};
