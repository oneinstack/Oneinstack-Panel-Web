import{bc as s}from"./index-Bt52GBD0.js";const i=i=>["",...s].includes(i);export{i};
