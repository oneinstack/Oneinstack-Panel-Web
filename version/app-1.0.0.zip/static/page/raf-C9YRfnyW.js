import{aj as e}from"./index-RpX_sd6o.js";const a=a=>e?window.requestAnimationFrame(a):setTimeout(a,16),i=a=>e?window.cancelAnimationFrame(a):clearTimeout(a);export{i as c,a as r};
