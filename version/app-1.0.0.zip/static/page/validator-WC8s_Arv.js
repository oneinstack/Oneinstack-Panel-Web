import{bq as s}from"./index-CLsYJaXM.js";const i=i=>["",...s].includes(i);export{i};
