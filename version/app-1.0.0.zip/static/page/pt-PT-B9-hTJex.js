const l={hello:"Olá"};export{l as default};
