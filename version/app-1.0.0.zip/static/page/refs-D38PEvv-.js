import{as as a}from"./index-BpgbG9_h.js";const o=(...o)=>s=>{o.forEach((o=>{a(o)?o(s):o.value=s}))};export{o as c};
