import{ah as a}from"./index-B1w6MNeq.js";const o=(...o)=>r=>{o.forEach((o=>{a(o)?o(r):o.value=r}))};export{o as c};
