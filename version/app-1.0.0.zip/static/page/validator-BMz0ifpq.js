import{bJ as s}from"./index-B1w6MNeq.js";const i=i=>["",...s].includes(i);export{i};
