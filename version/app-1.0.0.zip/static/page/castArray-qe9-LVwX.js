import{bN as r}from"./index-BXPEKZZX.js";function n(){if(!arguments.length)return[];var n=arguments[0];return r(n)?n:[n]}export{n as c};
