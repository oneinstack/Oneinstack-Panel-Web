import{bd as s}from"./index-yIUVo_Fb.js";const i=i=>["",...s].includes(i);export{i};
