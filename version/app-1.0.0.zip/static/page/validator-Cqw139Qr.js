import{bg as s}from"./index-CiGUvZ0x.js";const i=i=>["",...s].includes(i);export{i};
