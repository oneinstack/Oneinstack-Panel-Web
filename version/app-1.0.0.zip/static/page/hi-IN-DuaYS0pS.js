const e={hello:"नमस्ते"};export{e as default};
