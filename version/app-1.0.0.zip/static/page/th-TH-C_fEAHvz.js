const e={hello:"สวัสดี"};export{e as default};
