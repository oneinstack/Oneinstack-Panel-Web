import{bQ as s}from"./index-DNcxel5W.js";const i=i=>["",...s].includes(i);export{i};
