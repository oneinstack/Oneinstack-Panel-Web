import{bm as s}from"./index-DIiXyywz.js";const i=i=>["",...s].includes(i);export{i};
