import{ah as a}from"./index-CLbr8x7R.js";const o=(...o)=>r=>{o.forEach((o=>{a(o)?o(r):o.value=r}))};export{o as c};
