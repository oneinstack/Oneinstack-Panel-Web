const l={hello:"Hello"};export{l as default};
