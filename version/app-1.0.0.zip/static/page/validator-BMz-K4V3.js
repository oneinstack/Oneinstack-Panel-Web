import{bo as o}from"./index-DTE6ZPzd.js";const s=s=>["",...o].includes(s);export{s as i};
