import{bm as s}from"./index-RpX_sd6o.js";const i=i=>["",...s].includes(i);export{i};
