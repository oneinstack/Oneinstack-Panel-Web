import{bP as s}from"./index-BXPEKZZX.js";const i=i=>["",...s].includes(i);export{i};
