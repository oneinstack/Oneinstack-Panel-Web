import{bm as s}from"./index-DCm8_778.js";const i=i=>["",...s].includes(i);export{i};
