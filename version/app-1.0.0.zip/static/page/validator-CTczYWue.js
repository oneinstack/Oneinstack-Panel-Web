import{bd as s}from"./index-DP8kN_e6.js";const i=i=>["",...s].includes(i);export{i};
