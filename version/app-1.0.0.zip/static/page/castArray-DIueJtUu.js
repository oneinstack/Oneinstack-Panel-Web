import{bH as r}from"./index-B1w6MNeq.js";function n(){if(!arguments.length)return[];var n=arguments[0];return r(n)?n:[n]}export{n as c};
