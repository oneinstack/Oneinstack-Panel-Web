import{bJ as s}from"./index-CLbr8x7R.js";const i=i=>["",...s].includes(i);export{i};
