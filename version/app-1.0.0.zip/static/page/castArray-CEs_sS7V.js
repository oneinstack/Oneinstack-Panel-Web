import{b9 as r}from"./index-Bt52GBD0.js";function n(){if(!arguments.length)return[];var n=arguments[0];return r(n)?n:[n]}export{n as c};
