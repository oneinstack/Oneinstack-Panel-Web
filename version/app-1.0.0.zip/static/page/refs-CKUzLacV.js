import{ah as a}from"./index-CiGUvZ0x.js";const o=(...o)=>r=>{o.forEach((o=>{a(o)?o(r):o.value=r}))};export{o as c};
