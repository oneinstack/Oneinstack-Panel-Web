import{cK as e}from"./index-DudTs9z5.js";const a=(e="")=>e.replace(/[|\\{}()[\]^$+*?.]/g,"\\$&").replace(/-/g,"\\x2d"),c=a=>e(a);export{c,a as e};
