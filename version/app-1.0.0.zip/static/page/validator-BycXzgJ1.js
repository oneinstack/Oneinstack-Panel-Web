import{bo as o}from"./index-BTRQcAp5.js";const s=s=>["",...o].includes(s);export{s as i};
