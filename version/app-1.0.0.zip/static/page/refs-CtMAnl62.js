import{as as a}from"./index-B0-DY18Y.js";const o=(...o)=>s=>{o.forEach((o=>{a(o)?o(s):o.value=s}))};export{o as c};
