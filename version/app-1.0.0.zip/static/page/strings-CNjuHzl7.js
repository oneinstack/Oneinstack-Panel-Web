import{cK as e}from"./index-B1w6MNeq.js";const a=(e="")=>e.replace(/[|\\{}()[\]^$+*?.]/g,"\\$&").replace(/-/g,"\\x2d"),c=a=>e(a);export{c,a as e};
