const l={hello:"Hola"};export{l as default};
