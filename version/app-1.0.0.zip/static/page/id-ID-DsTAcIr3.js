const l={hello:"Halo"};export{l as default};
