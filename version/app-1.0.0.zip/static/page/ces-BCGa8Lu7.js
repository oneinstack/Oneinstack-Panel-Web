import{_ as r}from"./_plugin-vue_export-helper-BCo6x5W8.js";import{b as e,o}from"./index-DlDh7WRC.js";const t=r({},[["render",function(r,t){return o(),e("div")}]]);export{t as default};
