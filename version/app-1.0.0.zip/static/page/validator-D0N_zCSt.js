import{bJ as s}from"./index-DudTs9z5.js";const i=i=>["",...s].includes(i);export{i};
