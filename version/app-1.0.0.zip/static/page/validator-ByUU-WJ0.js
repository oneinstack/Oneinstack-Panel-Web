import{bB as s}from"./index-BpgbG9_h.js";const i=i=>["",...s].includes(i);export{i};
