import{bO as s}from"./index--T9q97Nz.js";const i=i=>["",...s].includes(i);export{i};
