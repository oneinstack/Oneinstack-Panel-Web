import{bJ as s}from"./index-BCXhlhFU.js";const i=i=>["",...s].includes(i);export{i};
