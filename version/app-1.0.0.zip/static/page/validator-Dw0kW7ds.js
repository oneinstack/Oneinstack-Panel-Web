import{bo as o}from"./index-BGoGknX4.js";const s=s=>["",...o].includes(s);export{s as i};
